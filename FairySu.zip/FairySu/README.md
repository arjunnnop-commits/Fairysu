# FairySu
FairySu: system image installer with proper live logs, preflight checks and error explanations. Root required.

Credit: **@yooitachiijod** — Telegram: https://t.me/FairysTeamBase

Build: push to GitHub, open Actions tab, download `FairySu-debug-apk` artifact.
