package com.fairy.su

/** Raw error -> plain English explanation. Add more rules as new errors show up. */
object ErrorDecoder {
    private val rules = listOf(
        "panic|watchdog|Oops" to "Kernel panic or watchdog reset. The FairySu kernel and vendor may be incompatible, or the GSI does not fit this device.",
        "ENOSPC|No space|not enough space|insufficient" to "Not enough free space on /data. Free up space or use a smaller userdata size.",
        "CAUSE_ERROR_INVALID_URL|invalid url" to "The image path or URL is invalid. Check the file path.",
        "CAUSE_ERROR_IO|IOException|I/O error" to "Read/write error. The image may be corrupt, or there is a storage problem.",
        "CAUSE_ERROR_EXCEPTION" to "The installer crashed. Check the logcat exception shown above or below.",
        "not supported|dynamic partitions|Dynamic partition" to "This device does not support dynamic partitions, or the feature is disabled.",
        "avb|verity|vbmeta" to "AVB/verity problem. Check the GSI vbmeta and the device verification state.",
        "already|in use|installed" to "A FairySu is already installed or running. Discard it first (gsi_tool wipe).",
        "gsid.*(fail|error)" to "The gsid service reported a failure. Check free space and the partition layout.",
        "Permission denied|SecurityException" to "Permission denied. Check that root access is granted.",
        "inflate|gz|xz|decompress" to "The compressed image could not be extracted. The file may be corrupt or in the wrong format."
    ).map { Regex(it.first, RegexOption.IGNORE_CASE) to it.second }

    fun explain(line: String): String? = rules.firstOrNull { it.first.containsMatchIn(line) }?.second
}
