package com.fairy.su

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.core.widget.doAfterTextChanged
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("fairysu", MODE_PRIVATE) }
    private val ts = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val dfmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
    private val sb = SpannableStringBuilder()
    private val plain = StringBuilder()
    private var proc: Process? = null
    @Volatile private var busy = false
    @Volatile private var autoSystem = 0L
    @Volatile private var autoEstimated = false

    private lateinit var titleTv: TextView
    private lateinit var navBtn: TextView
    private lateinit var rootDot: TextView
    private lateinit var pages: List<View>
    private lateinit var navItems: List<TextView>
    private var current = 0

    private lateinit var pathIn: EditText
    private lateinit var infoTv: TextView
    private lateinit var installBtn: TextView
    private lateinit var installCard: LinearLayout
    private lateinit var presentCard: LinearLayout
    private lateinit var usrSwitch: Switch
    private lateinit var usrBox: LinearLayout
    private lateinit var usrIn: EditText
    private lateinit var usrHint: TextView
    private lateinit var sysSwitch: Switch
    private lateinit var sysBox: LinearLayout
    private lateinit var sysIn: EditText
    private lateinit var sysHint: TextView
    private lateinit var progress: ProgressBar
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var partsBox: LinearLayout
    private lateinit var logsBox: LinearLayout
    private lateinit var typeRow: LinearLayout
    private lateinit var dateRow: LinearLayout
    private var typeFilter = "all"
    private var dateFilter = 0

    // ---------- small helpers ----------
    private fun bg(f: () -> Unit) = Thread(f).start()
    private fun gb(b: Long) = String.format(Locale.US, "%.2f GB", b / GIB.toDouble())
    private fun lp(w: Int, h: Int, wt: Float = 0f, m: Int = 0) =
        LinearLayout.LayoutParams(w, h, wt).apply { setMargins(dp(m), dp(m), dp(m), dp(m)) }
    private fun row() = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
    private fun card(r: Int = 20, pad: Int = 14) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.glass(this@MainActivity, r)
        setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    }
    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun page(): Pair<ScrollView, LinearLayout> {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(8)) }
        return ScrollView(this).apply { addView(col); isVerticalScrollBarEnabled = false } to col
    }
    private fun add(col: LinearLayout, v: View) = col.addView(v, lp(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(10) })
    private fun below(v: View, top: Int = 10) = lp(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(top) }
    private fun dlg() = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
    private fun toast(m: String) = runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_LONG).show() }

    private fun toggle(title: String, sub: String, on: Boolean, change: (Boolean) -> Unit): Pair<LinearLayout, Switch> {
        val r = row()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(tv(title, 15f, Ui.TEXT, true)); col.addView(tv(sub, 11f, Ui.DIM))
        val sw = Switch(this).apply {
            isChecked = on
            thumbTintList = ColorStateList.valueOf(Ui.PURPLE_L)
            trackTintList = ColorStateList.valueOf(Color.parseColor("#667C3AED"))
            setOnCheckedChangeListener { _, v -> change(v) }
        }
        r.addView(col, lp(0, WRAP_CONTENT, 1f)); r.addView(sw)
        return r to sw
    }

    // ---------- lifecycle / shell ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setBackgroundDrawable(GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#090611"), Color.parseColor("#1B0E36"))))
        window.statusBarColor = Color.parseColor("#090611")
        window.navigationBarColor = Color.parseColor("#1B0E36")

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(10)) }
        val header = row().apply { setPadding(dp(4), dp(4), dp(4), dp(10)) }
        titleTv = tv("FairySu", 22f, Ui.TEXT, true)
        header.addView(titleTv, lp(0, WRAP_CONTENT, 1f))
        rootDot = tv("● root?", 12f, Ui.DIM)
        header.addView(rootDot, lp(WRAP_CONTENT, WRAP_CONTENT).apply { rightMargin = dp(10) })
        navBtn = Ui.pill(this, "⚙", false) { show(if (current == 3) 0 else 3) }.apply { setPadding(dp(14), dp(8), dp(14), dp(8)) }
        header.addView(navBtn)
        root.addView(header, lp(MATCH_PARENT, WRAP_CONTENT))

        val frame = FrameLayout(this)
        pages = listOf(installPage(), partsPage(), logsPage(), settingsPage())
        pages.forEach { frame.addView(it, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)) }
        root.addView(frame, lp(MATCH_PARENT, 0, 1f))

        val bar = row().apply { background = Ui.glass(this@MainActivity, 26); setPadding(dp(6), dp(6), dp(6), dp(6)) }
        navItems = listOf("⬇  Install", "▦  Partitions", "≡  Logs").mapIndexed { i, n -> Ui.pill(this, n, false) { show(i) } }
        navItems.forEach { bar.addView(it, lp(0, WRAP_CONTENT, 1f, 2)) }
        root.addView(bar, below(bar, 8))
        setContentView(root)

        show(0)
        log("I", "FairySu ready. Select an image and tap Install.")
        bg {
            val ok = RootShell.hasRoot()
            runOnUiThread {
                rootDot.text = if (ok) "● root OK" else "● no root"
                rootDot.setTextColor(if (ok) Color.rgb(120, 255, 170) else Color.rgb(255, 90, 90))
            }
        }
    }

    override fun onResume() { super.onResume(); refreshState(); if (current == 1) loadPartitions() }
    override fun onBackPressed() { if (current == 3) show(0) else super.onBackPressed() }
    override fun onDestroy() { busy = false; proc?.destroy(); super.onDestroy() }

    private fun show(i: Int) {
        current = i
        pages.forEachIndexed { idx, p -> p.visibility = if (idx == i) View.VISIBLE else View.GONE }
        navItems.forEachIndexed { idx, t -> Ui.style(this, t, idx == i) }
        titleTv.text = listOf("FairySu", "Partitions", "Logs", "Settings")[i]
        navBtn.text = if (i == 3) "✕" else "⚙"
        when (i) { 0 -> refreshState(); 1 -> loadPartitions(); 2 -> loadLogs() }
    }

    // ---------- Install page ----------
    private fun installPage(): View {
        val (sv, col) = page()

        installCard = card()
        installCard.addView(tv("Install", 16f, Ui.TEXT, true))
        pathIn = Ui.field(this, "Select a file to be installed (zip / img / gz)")
        pathIn.setOnFocusChangeListener { _, f -> if (!f) captureInfo() }
        installCard.addView(pathIn, below(pathIn))
        val r = row()
        r.addView(Ui.pill(this, "Browse", false) { browse() }, lp(0, WRAP_CONTENT, 1f, 2))
        r.addView(Ui.pill(this, "Clear", false) { pathIn.setText(""); infoTv.text = ""; autoSystem = 0L; updateMax() }, lp(0, WRAP_CONTENT, 1f, 2))
        installCard.addView(r, below(r, 8))
        infoTv = tv("", 11f, Ui.PURPLE_L)
        installCard.addView(infoTv, below(infoTv, 8))
        installBtn = Ui.pill(this, "Install", true) { install() }
        installCard.addView(installBtn, below(installBtn))
        add(col, installCard)

        presentCard = card()
        presentCard.visibility = View.GONE
        presentCard.addView(tv("A DSU installation is already present.", 14f, Ui.TEXT, true))
        val pr = row()
        pr.addView(Ui.pill(this, "Discard", false) { confirmDiscard() }, lp(0, WRAP_CONTENT, 1f, 2))
        pr.addView(Ui.pill(this, "Reboot into DSU", true) { bootDsu() }, lp(0, WRAP_CONTENT, 1f, 2))
        presentCard.addView(pr, below(pr))
        add(col, presentCard)

        // Userdata size
        val c2 = card()
        usrIn = Ui.field(this, "Size in gigabytes").apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        usrHint = tv("", 11f, Ui.DIM)
        usrBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        usrBox.addView(usrIn, below(usrIn)); usrBox.addView(usrHint, below(usrHint, 6))
        val (t1, s1) = toggle("Userdata size", "Off: automatic (up to 8 GB, limited by free space)", false) { on ->
            usrBox.visibility = if (on) View.VISIBLE else View.GONE; updateMax()
        }
        usrSwitch = s1
        c2.addView(t1); c2.addView(usrBox)
        add(col, c2)

        // Image (system) size
        val c3 = card()
        sysIn = Ui.field(this, "Size in gigabytes").apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        sysIn.doAfterTextChanged { updateMax() }
        sysHint = tv("", 11f, Ui.DIM)
        sysBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        sysBox.addView(sysIn, below(sysIn)); sysBox.addView(sysHint, below(sysHint, 6))
        val (t2, s2) = toggle("Image size", "Off: captured automatically from the image", false) { on ->
            sysBox.visibility = if (on) View.VISIBLE else View.GONE; updateMax()
        }
        sysSwitch = s2
        c3.addView(t2); c3.addView(sysBox)
        add(col, c3)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true; visibility = View.GONE
            indeterminateTintList = ColorStateList.valueOf(Ui.PURPLE)
        }
        col.addView(progress, lp(MATCH_PARENT, dp(6)).apply { bottomMargin = dp(10) })

        val logCard = card(18, 10)
        logCard.addView(tv("Live log", 12f, Ui.DIM))
        logView = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 11f; setTextColor(Ui.TEXT); setTextIsSelectable(true) }
        scroll = ScrollView(this).apply {
            addView(logView)
            setOnTouchListener { v, _ -> v.parent.requestDisallowInterceptTouchEvent(true); false }
        }
        logCard.addView(scroll, lp(MATCH_PARENT, dp(260)))
        add(col, logCard)

        val c4 = card()
        c4.addView(tv("What is DSU?", 15f, Ui.TEXT, true))
        c4.addView(tv("Dynamic System Updates (Android 10+) lets you boot a system image without touching your device partitions. " +
            "FairySu installs the image, records detailed logs, and returns you to your main OS if anything fails.", 12f, Ui.DIM), below(c4, 6))
        add(col, c4)

        col.addView(tv("Made by @yooitachiijod  •  t.me/FairysTeamBase", 11f, Ui.PURPLE_L).apply {
            gravity = Gravity.CENTER
            setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/FairysTeamBase"))) }
        }, lp(MATCH_PARENT, WRAP_CONTENT))
        return sv
    }

    private fun refreshState() = bg {
        val inst = DsuRunner.isInstalled()
        runOnUiThread {
            installCard.visibility = if (inst) View.GONE else View.VISIBLE
            presentCard.visibility = if (inst) View.VISIBLE else View.GONE
        }
    }

    private fun browse() = bg {
        val out = RootShell.run("find /sdcard -maxdepth 4 -type f \\( -iname '*.zip' -o -iname '*.img' -o -iname '*.gz' -o -iname '*.xz' \\) 2>/dev/null | head -100").second
        val files = out.lines().filter { it.startsWith("/") }
        runOnUiThread {
            if (files.isEmpty()) {
                toast("No image found in /sdcard. Type the path manually.")
            } else {
                dlg().setTitle("Select image")
                    .setItems(files.map { it.removePrefix("/sdcard/") }.toTypedArray()) { _, i ->
                        pathIn.setText(files[i]); captureInfo()
                    }.show()
            }
        }
    }

    /** Auto-capture: reads the image (or zip contents) and fills in the system size. */
    private fun captureInfo() {
        val path = pathIn.text.toString().trim()
        if (path.isEmpty()) return
        bg {
            val cap = ImageInfo.capture(path)
            autoSystem = cap.systemSize ?: 0L
            autoEstimated = cap.estimated
            val sbd = StringBuilder()
            cap.images.forEach { sbd.append("• ${it.first}  ${gb(it.second)}\n") }
            sbd.append(when {
                cap.systemSize == null -> "System size could not be captured. Turn on Image size and enter it."
                cap.estimated -> "System size (estimated from zip size): ${gb(cap.systemSize)}"
                else -> "System size (auto-captured): ${gb(cap.systemSize)}"
            })
            runOnUiThread { infoTv.text = sbd.toString(); updateMax() }
        }
    }

    private fun updateMax() {
        val manual = sysSwitch.isChecked
        val txt = sysIn.text.toString()
        bg {
            val free = DsuRunner.freeBytes()
            val sys = if (manual) ((txt.toDoubleOrNull() ?: 0.0) * GIB).toLong() else autoSystem
            val max = if (free == null) -1L else maxOf(0L, (free - sys) / GIB)
            runOnUiThread {
                usrHint.text = if (max < 0) "Could not read free space." else "Maximum available for allocation: ${max}GB"
                sysHint.text = if (autoSystem > 0) "Auto-captured: ${gb(autoSystem)}" else "Select an image to capture its size automatically."
            }
        }
    }

    private fun setBusy(on: Boolean) = runOnUiThread {
        progress.visibility = if (on) View.VISIBLE else View.GONE
        installBtn.text = if (on) "Installing..." else "Install"
        installBtn.alpha = if (on) 0.6f else 1f
    }

    private fun fail(m: String) { log("E", m); toast(m) }

    private fun install() {
        val path = pathIn.text.toString().trim()
        val manualSys = sysSwitch.isChecked; val sysTxt = sysIn.text.toString().trim()
        val manualUsr = usrSwitch.isChecked; val usrTxt = usrIn.text.toString().trim()
        bg {
            if (busy) { log("W", "An installation is already in progress."); return@bg }
            if (path.isEmpty()) { fail("Select an image first."); return@bg }
            if (!RootShell.hasRoot()) { fail("Root access is not available. Grant FairySu root in KernelSU/Magisk."); return@bg }
            if (RootShell.run("test -f ${DsuRunner.q(path)} && echo ok").second != "ok") { fail("File not found: $path"); return@bg }
            if (path.endsWith(".img", true) && DsuRunner.isSparse(path)) {
                fail("Sparse image detected. DSU needs a raw image (convert it with simg2img)."); return@bg
            }
            if (DsuRunner.isInstalled()) { fail("A DSU is already installed. Discard it first."); refreshState(); return@bg }

            val cap = ImageInfo.capture(path)
            autoSystem = cap.systemSize ?: 0L
            val s = if (manualSys) ((sysTxt.toDoubleOrNull() ?: 0.0) * GIB).toLong() else (cap.systemSize ?: 0L)
            if (s <= 0L) { fail("Could not determine the system size. Turn on Image size and enter it."); return@bg }
            val free = DsuRunner.freeBytes()
            val maxUsr = if (free != null) free - s else Long.MAX_VALUE
            if (maxUsr < GIB) { fail("Not enough space on /data: ${gb(free ?: 0L)} free, ${gb(s)} needed for the system image."); return@bg }
            val u = if (manualUsr) ((usrTxt.toDoubleOrNull() ?: 0.0) * GIB).toLong() else minOf(8L * GIB, (maxUsr / GIB) * GIB)
            if (u <= 0L || u > maxUsr) { fail("Userdata size must be between 1 and ${maxUsr / GIB} GB."); return@bg }

            synchronized(plain) { plain.setLength(0) }
            runOnUiThread { sb.clear(); sb.clearSpans(); logView.text = "" }
            log("I", "Image: $path")
            log("I", "System=${gb(s)}  Userdata=${gb(u)}  Free=${gb(free ?: 0L)}")
            busy = true; setBusy(true)
            proc?.destroy()
            proc = DsuRunner.tail { line -> log(levelOf(line), line) }
            log("I", DsuRunner.start(path, s, u).ifBlank { "Installer launched." })
            log("I", "Progress is shown in the DSU notification.")
            var i = 0
            while (busy && i < 450) {
                Thread.sleep(4000); i++
                if (DsuRunner.isInstalled()) { log("I", "DSU installation complete. Tap Reboot into DSU."); break }
            }
            val ok = DsuRunner.isInstalled()
            if (!ok) log("W", "Installation did not report completion. Check the log above.")
            busy = false; setBusy(false)
            LogStore.save(this, "install", if (ok) "installation success" else "installation incomplete", synchronized(plain) { plain.toString() })
            refreshState()
        }
    }

    private fun confirmDiscard() {
        dlg().setTitle("Discard installation?")
            .setMessage("All data in the installed DSU will be deleted. Are you sure?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Yes") { _, _ ->
                bg { setBusy(true); log("W", "Removing DSU..."); log("W", DsuRunner.discard()); setBusy(false); refreshState() }
            }.show()
    }

    private fun bootDsu() {
        val one = prefs.getBoolean("oneShot", true)
        dlg().setTitle("Reboot into DSU?")
            .setMessage(if (one) "The device will reboot into the DSU. If it crashes, or you reboot again, it returns to the main OS."
                        else "One-shot is OFF. The device will keep booting the DSU until you discard it.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Reboot") { _, _ ->
                bg {
                    log("I", "enable(${if (one) "one-shot" else "persistent"}): " + DsuRunner.enable(one))
                    log("I", "Rebooting...")
                    RootShell.run("reboot")
                }
            }.show()
    }

    private fun preflight() = bg {
        DsuRunner.preflight().forEach { (k, v) -> log(if (v.contains("NOT") || v == "n/a") "W" else "I", "$k: $v") }
    }

    private fun levelOf(line: String) = Regex("""\s([VDIWEF])\s""").find(line)?.groupValues?.get(1) ?: "I"

    private fun log(level: String, line: String) {
        val stamp = synchronized(ts) { ts.format(Date()) }
        val text = "[$stamp] $line\n"
        val hint = ErrorDecoder.explain(line)?.takeIf { level == "E" || level == "F" || line.contains("fail", true) }
        synchronized(plain) { plain.append(text); if (hint != null) plain.append("   >> FIX: $hint\n") }
        runOnUiThread {
            val color = when (level) {
                "E", "F" -> Color.rgb(255, 90, 90); "W" -> Color.rgb(255, 180, 60)
                "D", "V" -> Color.GRAY; else -> Color.rgb(170, 140, 255)
            }
            var st = sb.length
            sb.append(text); sb.setSpan(ForegroundColorSpan(color), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (hint != null) {
                st = sb.length
                sb.append("   >> FIX: $hint\n")
                sb.setSpan(ForegroundColorSpan(Color.rgb(90, 200, 255)), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            if (sb.length > 200_000) sb.delete(0, 50_000)
            logView.text = sb
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    // ---------- Partitions page ----------
    private fun partsPage(): View {
        val (sv, col) = page()
        val top = row()
        top.addView(tv("Installed DSU images", 14f, Ui.DIM), lp(0, WRAP_CONTENT, 1f))
        top.addView(Ui.chip(this, "↻ Refresh", false) { loadPartitions() })
        col.addView(top, lp(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(10) })
        partsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(partsBox, lp(MATCH_PARENT, WRAP_CONTENT))
        return sv
    }

    private fun loadPartitions() = bg {
        val out = RootShell.run("find /data/gsi -type f -exec stat -c '%s %n' {} + 2>/dev/null").second
        val items = out.lines().mapNotNull { l ->
            val i = l.indexOf(' ')
            if (i > 0 && l.substring(0, i).toLongOrNull() != null) l.substring(i + 1) to (l.substring(0, i).toLongOrNull() ?: 0L) else null
        }
        runOnUiThread {
            partsBox.removeAllViews()
            if (items.isEmpty()) {
                partsBox.addView(tv("No DSU images found on this device.", 13f, Ui.DIM).apply { gravity = Gravity.CENTER; setPadding(0, dp(60), 0, 0) }, lp(MATCH_PARENT, WRAP_CONTENT))
            } else items.forEach { (p, sz) ->
                val c = card(16, 12)
                c.addView(tv(p.substringAfterLast('/'), 14f, Ui.TEXT, true))
                c.addView(tv("${gb(sz)}  •  $p", 11f, Ui.DIM))
                partsBox.addView(c, lp(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(8) })
            }
        }
    }

    // ---------- Logs page ----------
    private fun logsPage(): View {
        val (sv, col) = page()
        val cap = card()
        cap.addView(tv("Capture", 15f, Ui.TEXT, true))
        cap.addView(tv("Save a crash report (boot reason, kernel last console, pstore, filtered logcat) or a logcat snapshot. Best used right after a DSU boot fails.", 11f, Ui.DIM), below(cap, 4))
        val r = row()
        r.addView(Ui.pill(this, "Crash report", true) { captureCrash() }, lp(0, WRAP_CONTENT, 1f, 2))
        r.addView(Ui.pill(this, "Logcat", false) { captureLogcat() }, lp(0, WRAP_CONTENT, 1f, 2))
        cap.addView(r, below(r))
        add(col, cap)

        val f = card()
        f.addView(tv("Filters", 14f, Ui.TEXT, true))
        typeRow = row(); dateRow = row()
        f.addView(typeRow, below(typeRow, 8)); f.addView(dateRow, below(dateRow, 6))
        add(col, f)
        buildChips()

        logsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(logsBox, lp(MATCH_PARENT, WRAP_CONTENT))
        return sv
    }

    private fun buildChips() {
        typeRow.removeAllViews(); dateRow.removeAllViews()
        listOf("all" to "All", "install" to "Install", "crash" to "Crash", "logcat" to "Logcat").forEach { (k, n) ->
            typeRow.addView(Ui.chip(this, n, typeFilter == k) { typeFilter = k; buildChips(); loadLogs() }, lp(WRAP_CONTENT, WRAP_CONTENT, 0f, 3))
        }
        listOf("All time", "Today", "Last 7 days").forEachIndexed { i, n ->
            dateRow.addView(Ui.chip(this, n, dateFilter == i) { dateFilter = i; buildChips(); loadLogs() }, lp(WRAP_CONTENT, WRAP_CONTENT, 0f, 3))
        }
    }

    private fun loadLogs() {
        val now = System.currentTimeMillis()
        val day = SimpleDateFormat("yyyyMMdd", Locale.US)
        val items = LogStore.list(this).filter {
            (typeFilter == "all" || it.type == typeFilter) && when (dateFilter) {
                1 -> day.format(Date(it.time)) == day.format(Date(now))
                2 -> now - it.time < 7 * 86_400_000L
                else -> true
            }
        }
        logsBox.removeAllViews()
        if (items.isEmpty()) logsBox.addView(tv("No logs yet.", 13f, Ui.DIM).apply { gravity = Gravity.CENTER; setPadding(0, dp(30), 0, 0) }, lp(MATCH_PARENT, WRAP_CONTENT))
        items.forEach { e ->
            val c = card(16, 12)
            c.addView(tv(e.name, 14f, Ui.TEXT, true))
            c.addView(tv("${e.type.replaceFirstChar { it.uppercase() }}  •  ${dfmt.format(Date(e.time))}  •  ${e.file.length() / 1024} KB", 11f, Ui.DIM))
            val br = row()
            br.addView(Ui.chip(this, "Read", false) { readLog(e) }, lp(WRAP_CONTENT, WRAP_CONTENT, 0f, 2))
            br.addView(Ui.chip(this, "Share", false) { shareLog(e) }, lp(WRAP_CONTENT, WRAP_CONTENT, 0f, 2))
            br.addView(Ui.chip(this, "Rename", false) { renameLog(e) }, lp(WRAP_CONTENT, WRAP_CONTENT, 0f, 2))
            br.addView(Ui.chip(this, "Delete", false) { deleteLog(e) }, lp(WRAP_CONTENT, WRAP_CONTENT, 0f, 2))
            c.addView(br, below(br, 8))
            logsBox.addView(c, lp(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(8) })
        }
    }

    private fun readLog(e: LogEntry) {
        val t = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 11f; setPadding(dp(16), dp(8), dp(16), dp(8)); setTextIsSelectable(true); text = e.file.readText().take(150_000) }
        dlg().setTitle(e.name).setView(ScrollView(this).apply { addView(t) }).setPositiveButton("Close", null).show()
    }

    private fun shareLog(e: LogEntry) {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, e.name); putExtra(Intent.EXTRA_TEXT, e.file.readText().take(100_000))
        }, "Share log"))
    }

    private fun renameLog(e: LogEntry) {
        val et = EditText(this).apply { setText(e.name); setPadding(dp(20), dp(16), dp(20), dp(16)) }
        dlg().setTitle("Rename log").setView(et).setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ -> LogStore.rename(e, et.text.toString()); loadLogs() }.show()
    }

    private fun deleteLog(e: LogEntry) {
        dlg().setTitle("Delete log?").setMessage(e.name).setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ -> e.file.delete(); loadLogs() }.show()
    }

    private fun captureCrash() = bg {
        val text = DsuRunner.lastBootReport().joinToString("\n\n") { "=== ${it.first} ===\n${it.second}" }
        LogStore.save(this, "crash", "crash report", text)
        toast("Crash report saved"); runOnUiThread { loadLogs() }
    }

    private fun captureLogcat() = bg {
        LogStore.save(this, "logcat", "logcat snapshot", RootShell.run("logcat -d -v threadtime | tail -n 4000").second)
        toast("Logcat snapshot saved"); runOnUiThread { loadLogs() }
    }

    // ---------- Settings page ----------
    private fun settingsPage(): View {
        val (sv, col) = page()
        val c = card()
        c.addView(tv("Install", 12f, Ui.PURPLE_L, true))
        val (r1, _) = toggle("One-shot boot", "Crash or reboot returns to your main OS", prefs.getBoolean("oneShot", true)) {
            prefs.edit().putBoolean("oneShot", it).apply()
        }
        c.addView(r1, below(r1, 8))
        add(col, c)

        val c2 = card()
        c2.addView(tv("Tools", 12f, Ui.PURPLE_L, true))
        c2.addView(Ui.pill(this, "Run preflight check", false) { show(0); preflight() }, below(c2, 8))
        c2.addView(Ui.pill(this, "GSI inspector", false) { inspector() }, below(c2, 8))
        add(col, c2)

        val c3 = card()
        c3.addView(tv("About", 12f, Ui.PURPLE_L, true))
        c3.addView(tv("FairySu", 16f, Ui.TEXT, true), below(c3, 8))
        c3.addView(tv("DSU flasher with proper logs. Operation mode: Root.", 12f, Ui.DIM))
        c3.addView(tv("Made by @yooitachiijod", 13f, Ui.PURPLE_L), below(c3, 8))
        c3.addView(tv("t.me/FairysTeamBase", 13f, Ui.PURPLE_L).apply {
            setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/FairysTeamBase"))) }
        })
        add(col, c3)
        return sv
    }

    private fun inspector() = bg {
        val body = "gsi_tool status:\n${DsuRunner.status()}\n\n/data/gsi:\n" + RootShell.run("ls -lR /data/gsi 2>&1 | head -n 80").second
        runOnUiThread {
            val t = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 11f; setPadding(dp(16), dp(8), dp(16), dp(8)); setTextIsSelectable(true); this.text = body }
            dlg().setTitle("GSI inspector").setView(ScrollView(this).apply { addView(t) }).setPositiveButton("Close", null).show()
        }
    }
}
