package com.fairy.su

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var pathIn: EditText
    private lateinit var sysIn: EditText
    private lateinit var usrIn: EditText
    private lateinit var oneShot: Switch
    private lateinit var progress: ProgressBar
    private lateinit var rootDot: TextView
    private val sb = SpannableStringBuilder()
    private val plain = StringBuilder()
    private var proc: Process? = null
    @Volatile private var busy = false
    private val ts = SimpleDateFormat("HH:mm:ss", Locale.US)

    private fun bg(f: () -> Unit) = Thread(f).start()
    private fun lp(w: Int, h: Int, wt: Float = 0f, m: Int = 0) =
        LinearLayout.LayoutParams(w, h, wt).apply { setMargins(dp(m), dp(m), dp(m), dp(m)) }
    private fun row() = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
    private fun card(r: Int = 20, pad: Int = 12) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.glass(this@MainActivity, r)
        setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setBackgroundDrawable(GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#090611"), Color.parseColor("#1B0E36"))))
        window.statusBarColor = Color.parseColor("#090611")
        window.navigationBarColor = Color.parseColor("#1B0E36")

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(10)) }

        // Header
        val header = row().apply { background = Ui.glass(this@MainActivity, 22); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        header.addView(TextView(this).apply {
            text = "F"; gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 20f
            typeface = Typeface.DEFAULT_BOLD; background = Ui.glow(this@MainActivity, 14)
        }, lp(dp(44), dp(44)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        titles.addView(TextView(this).apply { text = "FairySu"; setTextColor(Ui.TEXT); textSize = 20f; typeface = Typeface.DEFAULT_BOLD })
        titles.addView(TextView(this).apply { text = "DSU flasher with proper logs"; setTextColor(Ui.DIM); textSize = 11f })
        header.addView(titles, lp(0, WRAP_CONTENT, 1f))
        rootDot = TextView(this).apply { text = "● root?"; setTextColor(Ui.DIM); textSize = 12f }
        header.addView(rootDot)
        root.addView(header, lp(MATCH_PARENT, WRAP_CONTENT))

        // Steps
        val steps = row()
        steps.addView(Ui.pill(this, "Preflight", false) { preflight() }, lp(0, WRAP_CONTENT, 1f, 4))
        steps.addView(Ui.pill(this, "Flash", true) { flash() }, lp(0, WRAP_CONTENT, 1f, 4))
        steps.addView(Ui.pill(this, "Boot DSU", false) { bootDsu() }, lp(0, WRAP_CONTENT, 1f, 4))
        root.addView(steps, lp(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) })

        // Inputs
        val inputs = card()
        val pathRow = row()
        pathIn = Ui.field(this, "Image path (/sdcard/Download/gsi.img.gz)")
        pathRow.addView(pathIn, lp(0, WRAP_CONTENT, 1f))
        pathRow.addView(Ui.pill(this, "Browse", false) { browse() }, lp(WRAP_CONTENT, WRAP_CONTENT).apply { leftMargin = dp(8) })
        inputs.addView(pathRow, lp(MATCH_PARENT, WRAP_CONTENT))
        val sizeRow = row()
        sysIn = Ui.field(this, "System bytes (auto)").apply { inputType = InputType.TYPE_CLASS_NUMBER }
        usrIn = Ui.field(this, "Userdata bytes").apply { inputType = InputType.TYPE_CLASS_NUMBER; setText("8589934592") }
        sizeRow.addView(sysIn, lp(0, WRAP_CONTENT, 1f))
        sizeRow.addView(usrIn, lp(0, WRAP_CONTENT, 1f).apply { leftMargin = dp(8) })
        inputs.addView(sizeRow, lp(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) })
        val toggleRow = row()
        oneShot = Switch(this).apply {
            isChecked = true
            thumbTintList = ColorStateList.valueOf(Ui.PURPLE_L)
            trackTintList = ColorStateList.valueOf(Color.parseColor("#667C3AED"))
        }
        toggleRow.addView(TextView(this).apply { text = "One-shot boot (crash or reboot returns to main OS)"; setTextColor(Ui.TEXT); textSize = 12f }, lp(0, WRAP_CONTENT, 1f))
        toggleRow.addView(oneShot)
        inputs.addView(toggleRow, lp(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(10) })
        root.addView(inputs, lp(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(10) })

        // Progress
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true; visibility = View.GONE
            indeterminateTintList = ColorStateList.valueOf(Ui.PURPLE)
        }
        root.addView(progress, lp(MATCH_PARENT, dp(6)).apply { topMargin = dp(10) })

        // Log
        logView = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 11f; setTextColor(Ui.TEXT); setTextIsSelectable(true) }
        scroll = ScrollView(this).apply { addView(logView) }
        val logCard = card(18, 10)
        logCard.addView(scroll, lp(MATCH_PARENT, MATCH_PARENT))
        root.addView(logCard, lp(MATCH_PARENT, 0, 1f).apply { topMargin = dp(10) })

        // Bottom bar
        val bar = row().apply { background = Ui.glass(this@MainActivity, 26); setPadding(dp(6), dp(6), dp(6), dp(6)) }
        bar.addView(Ui.pill(this, "↻ Status", false) { bg { log("I", "DSU status: " + DsuRunner.status()) } }, lp(0, WRAP_CONTENT, 1f, 2))
        bar.addView(Ui.pill(this, "✕ Discard", false) { discard() }, lp(0, WRAP_CONTENT, 1f, 2))
        bar.addView(Ui.pill(this, "⚠ Crash", false) { crashReport() }, lp(0, WRAP_CONTENT, 1f, 2))
        bar.addView(Ui.pill(this, "⇪ Export", true) { export() }, lp(0, WRAP_CONTENT, 1f, 2))
        root.addView(bar, lp(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(10) })

        // Credit
        root.addView(TextView(this).apply {
            text = "Made by @yooitachiijod  •  t.me/FairysTeamBase"
            gravity = Gravity.CENTER; setTextColor(Ui.PURPLE_L); textSize = 11f
            setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/FairysTeamBase"))) }
        }, lp(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) })

        setContentView(root)
        log("I", "FairySu ready. Run Preflight first.")
        bg {
            val ok = RootShell.hasRoot()
            runOnUiThread {
                rootDot.text = if (ok) "● root OK" else "● no root"
                rootDot.setTextColor(if (ok) Color.rgb(120, 255, 170) else Color.rgb(255, 90, 90))
            }
        }
    }

    private fun preflight() = bg {
        DsuRunner.preflight().forEach { (k, v) -> log(if (v.contains("NOT") || v == "n/a") "W" else "I", "$k: $v") }
    }

    private fun browse() = bg {
        val out = RootShell.run("find /sdcard -maxdepth 3 -type f \\( -iname '*.img' -o -iname '*.gz' -o -iname '*.xz' \\) 2>/dev/null | head -50").second
        val files = out.lines().filter { it.startsWith("/") }
        runOnUiThread {
            if (files.isEmpty()) {
                log("W", "No image found in /sdcard. Enter the path manually.")
            } else {
                AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                    .setTitle("Select image")
                    .setItems(files.map { it.removePrefix("/sdcard/") }.toTypedArray()) { _, i ->
                        pathIn.setText(files[i])
                        bg {
                            val s = DsuRunner.autoSize(files[i])
                            runOnUiThread { sysIn.setText(s?.toString() ?: "") }
                            log(if (s == null) "W" else "I", if (s == null) "Could not detect the size automatically. Enter it manually." else "Auto size: ${s / 1048576} MB")
                        }
                    }.show()
            }
        }
    }

    private fun flash() {
        val path = pathIn.text.toString().trim()
        val sysTxt = sysIn.text.toString().trim()
        val usrTxt = usrIn.text.toString().trim()
        bg {
            if (busy) { log("W", "A flash is already in progress."); return@bg }
            if (path.isEmpty()) { log("E", "Enter an image path or tap Browse."); return@bg }
            if (!RootShell.hasRoot()) { log("E", "Root access is not available. Grant FairySu root in KernelSU/Magisk."); return@bg }
            if (RootShell.run("test -f ${DsuRunner.q(path)} && echo ok").second != "ok") { log("E", "File not found: $path"); return@bg }
            if (path.endsWith(".img", true) && DsuRunner.isSparse(path)) {
                log("E", "Sparse image detected. DSU needs a raw image (convert it with simg2img)."); return@bg
            }
            if (DsuRunner.isInstalled()) { log("E", "A DSU is already installed. Tap Discard, then flash again."); return@bg }
            val s = sysTxt.toLongOrNull() ?: DsuRunner.autoSize(path)
            if (s == null || s <= 0) { log("E", "Could not detect the system size (.xz?). Enter it manually in bytes."); return@bg }
            val u = usrTxt.toLongOrNull() ?: 8589934592L
            val free = DsuRunner.freeBytes()
            if (free != null && free < s) { log("E", "Not enough space on /data: ${free / 1048576} MB free, ~${s / 1048576} MB required."); return@bg }
            log("I", "System=${s / 1048576} MB, Userdata=${u / 1048576} MB, free=${(free ?: 0) / 1048576} MB")
            busy = true; setBusy(true)
            proc?.destroy()
            proc = DsuRunner.tail { line -> log(levelOf(line), line) }
            log("I", DsuRunner.start(path, s, u).ifBlank { "Installer launched." })
            log("I", "Progress is shown in the DSU notification. Tap Boot DSU when it completes.")
            var i = 0
            while (busy && i < 450) {
                Thread.sleep(4000); i++
                if (DsuRunner.isInstalled()) { log("I", "DSU installation complete. Tap Boot DSU."); break }
            }
            busy = false; setBusy(false)
        }
    }

    private fun bootDsu() {
        val one = oneShot.isChecked
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Boot DSU?")
            .setMessage(if (one) "The device will reboot into the DSU. If it crashes, or you reboot again, it returns to the main OS."
                        else "One-shot is OFF. The device will keep booting the DSU until you discard it.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Reboot") { _, _ ->
                bg {
                    if (!DsuRunner.isInstalled()) log("W", "The DSU does not appear to be installed; trying anyway.")
                    log("I", "enable(${if (one) "one-shot" else "persistent"}): " + DsuRunner.enable(one))
                    log("I", "Rebooting...")
                    RootShell.run("reboot")
                }
            }.show()
    }

    private fun crashReport() = bg {
        log("I", "=== Last boot / crash report ===")
        val bad = Regex("panic|fatal|oops|watchdog|fail|crash|avb|verity", RegexOption.IGNORE_CASE)
        DsuRunner.lastBootReport().forEach { (k, v) ->
            log("I", "--- $k ---")
            v.lines().take(120).forEach { l -> log(if (bad.containsMatchIn(l)) "E" else "D", l) }
        }
        log("I", "=== End of report. Tap Export to share it ===")
    }

    private fun discard() = bg { log("W", "Discard: " + DsuRunner.discard()) }

    private fun setBusy(on: Boolean) = runOnUiThread { progress.visibility = if (on) View.VISIBLE else View.GONE }

    private fun levelOf(line: String) = Regex("""\s([VDIWEF])\s""").find(line)?.groupValues?.get(1) ?: "I"

    private fun log(level: String, line: String) = runOnUiThread {
        val color = when (level) {
            "E", "F" -> Color.rgb(255, 90, 90); "W" -> Color.rgb(255, 180, 60)
            "D", "V" -> Color.GRAY; else -> Color.rgb(170, 140, 255)
        }
        val text = "[${ts.format(Date())}] $line\n"
        val start = sb.length
        sb.append(text); sb.setSpan(ForegroundColorSpan(color), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        plain.append(text)
        ErrorDecoder.explain(line)?.takeIf { level == "E" || level == "F" || line.contains("fail", true) }?.let {
            val s2 = sb.length
            val hint = "   >> FIX: $it\n"
            sb.append(hint); sb.setSpan(ForegroundColorSpan(Color.rgb(90, 200, 255)), s2, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            plain.append(hint)
        }
        logView.text = sb
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun export() {
        val f = File(getExternalFilesDir(null), "fairysu_${System.currentTimeMillis()}.txt")
        f.writeText(plain.toString())
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, plain.toString())
        }, "Share log"))
        log("I", "Saved: ${f.absolutePath}")
    }

    override fun onDestroy() { busy = false; proc?.destroy(); super.onDestroy() }
}
