package com.fairy.su

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.EditText
import android.widget.TextView

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

/** Dark purple "liquid glass" look. */
object Ui {
    val PURPLE = Color.parseColor("#9B5CFF")
    val PURPLE_L = Color.parseColor("#D2B8FF")
    val TEXT = Color.parseColor("#F1EAFF")
    val DIM = Color.parseColor("#9A8DB8")

    fun glass(c: Context, r: Int) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.parseColor("#2EFFFFFF"), Color.parseColor("#0FFFFFFF"))
    ).apply { cornerRadius = c.dp(r).toFloat(); setStroke(c.dp(1), Color.parseColor("#44B79CFF")) }

    fun glow(c: Context, r: Int) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.parseColor("#7C3AED"), Color.parseColor("#B58CFF"))
    ).apply { cornerRadius = c.dp(r).toFloat(); setStroke(c.dp(1), Color.parseColor("#AAE3D0FF")) }

    fun pill(c: Context, label: String, primary: Boolean, onClick: () -> Unit) = TextView(c).apply {
        text = label; gravity = Gravity.CENTER; textSize = 13f
        setTextColor(if (primary) Color.WHITE else TEXT)
        setPadding(c.dp(12), c.dp(12), c.dp(12), c.dp(12))
        background = if (primary) glow(c, 22) else glass(c, 22)
        if (primary) {
            typeface = Typeface.DEFAULT_BOLD
            elevation = c.dp(8).toFloat()
            outlineSpotShadowColor = PURPLE
            outlineAmbientShadowColor = PURPLE
        }
        setOnClickListener { onClick() }
    }

    fun field(c: Context, hint: String) = EditText(c).apply {
        this.hint = hint; setHintTextColor(DIM); setTextColor(TEXT); textSize = 13f; isSingleLine = true
        background = glass(c, 14); setPadding(c.dp(12), c.dp(10), c.dp(12), c.dp(10))
    }
}
