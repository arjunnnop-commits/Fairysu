package com.fairy.su

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.EditText
import android.widget.TextView

const val GIB = 1073741824L

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

/** Dark purple "liquid glass" look. */
object Ui {
    val PURPLE = Color.parseColor("#9B5CFF")
    val PURPLE_L = Color.parseColor("#D2B8FF")
    val TEXT = Color.parseColor("#F1EAFF")
    val DIM = Color.parseColor("#9A8DB8")

    fun glass(c: Context, r: Int) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.parseColor("#2EFFFFFF"), Color.parseColor("#0FFFFFFF"))
    ).apply { cornerRadius = c.dp(r).toFloat(); setStroke(c.dp(1), Color.parseColor("#44B79CFF")) }

    fun glow(c: Context, r: Int) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.parseColor("#7C3AED"), Color.parseColor("#B58CFF"))
    ).apply { cornerRadius = c.dp(r).toFloat(); setStroke(c.dp(1), Color.parseColor("#AAE3D0FF")) }

    fun style(c: Context, t: TextView, selected: Boolean, r: Int = 22) {
        t.background = if (selected) glow(c, r) else glass(c, r)
        t.setTextColor(if (selected) Color.WHITE else TEXT)
        t.typeface = if (selected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        t.elevation = if (selected) c.dp(8).toFloat() else 0f
        if (selected) { t.outlineSpotShadowColor = PURPLE; t.outlineAmbientShadowColor = PURPLE }
    }

    fun pill(c: Context, label: String, primary: Boolean, onClick: () -> Unit) = TextView(c).apply {
        text = label; gravity = Gravity.CENTER; textSize = 13f
        setPadding(c.dp(12), c.dp(12), c.dp(12), c.dp(12))
        style(c, this, primary)
        setOnClickListener { onClick() }
    }

    fun chip(c: Context, label: String, selected: Boolean, onClick: () -> Unit) =
        pill(c, label, selected, onClick).apply {
            textSize = 12f; setPadding(c.dp(12), c.dp(7), c.dp(12), c.dp(7)); style(c, this, selected, 16)
        }

    fun field(c: Context, hint: String) = EditText(c).apply {
        this.hint = hint; setHintTextColor(DIM); setTextColor(TEXT); textSize = 13f; isSingleLine = true
        background = glass(c, 14); setPadding(c.dp(12), c.dp(10), c.dp(12), c.dp(10))
    }
}
