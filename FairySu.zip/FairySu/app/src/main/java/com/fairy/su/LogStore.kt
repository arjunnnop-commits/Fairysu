package com.fairy.su

import android.content.Context
import java.io.File

class LogEntry(val file: File, val type: String, val name: String, val time: Long)

/** Logs live in <app external files>/logs as type__name__epoch.txt */
object LogStore {
    fun dir(c: Context) = (c.getExternalFilesDir("logs") ?: File(c.filesDir, "logs")).apply { mkdirs() }

    fun clean(s: String) = s.trim().replace(Regex("[^A-Za-z0-9 ]"), "").replace(Regex("\\s+"), "_").ifEmpty { "log" }

    fun save(c: Context, type: String, name: String, text: String): File =
        File(dir(c), "${type}__${clean(name)}__${System.currentTimeMillis()}.txt").also { it.writeText(text) }

    fun list(c: Context): List<LogEntry> = (dir(c).listFiles() ?: emptyArray()).mapNotNull { f ->
        val p = f.name.removeSuffix(".txt").split("__")
        if (p.size == 3) LogEntry(f, p[0], p[1].replace('_', ' '), p[2].toLongOrNull() ?: f.lastModified()) else null
    }.sortedByDescending { it.time }

    fun rename(e: LogEntry, newName: String): Boolean =
        e.file.renameTo(File(e.file.parentFile, "${e.type}__${clean(newName)}__${e.time}.txt"))
}
