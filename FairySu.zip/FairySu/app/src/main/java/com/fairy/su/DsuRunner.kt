package com.fairy.su

object DsuRunner {
    const val TAGS = "DynamicSystemService:V DynSystem:V DynamicSystemInstallationService:V " +
        "DynamicSystemManager:V gsid:V libfiemap:V libsnapshot:V update_engine:V AndroidRuntime:E"

    fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    fun preflight(): List<Pair<String, String>> {
        fun sh(c: String) = RootShell.run(c).second.ifBlank { "n/a" }
        return listOf(
            "Root" to if (RootShell.hasRoot()) "OK" else "NOT GRANTED",
            "Android" to sh("getprop ro.build.version.release") + " (SDK " + sh("getprop ro.build.version.sdk") + ")",
            "Dynamic partitions" to sh("getprop ro.boot.dynamic_partitions"),
            "A/B slot" to sh("getprop ro.boot.slot_suffix"),
            "ABI" to sh("getprop ro.product.cpu.abi"),
            "DSU status" to sh("gsi_tool status"),
            "/data free" to ((freeBytes()?.div(1048576))?.toString()?.plus(" MB") ?: "n/a"),
            "dynsystem app" to sh("pm path com.android.dynsystem")
        )
    }

    fun freeBytes(): Long? {
        val p = RootShell.run("stat -f -c '%a %S' /data").second.trim().split(" ")
        if (p.size != 2) return null
        val a = p[0].toLongOrNull() ?: return null
        val b = p[1].toLongOrNull() ?: return null
        return a * b
    }

    fun isSparse(path: String) =
        RootShell.run("head -c 4 ${q(path)} | od -An -tx1").second.replace(" ", "") == "3aff26ed"

    /** Uncompressed size in bytes. .xz not supported (returns null). */
    fun autoSize(path: String): Long? {
        val f = q(path)
        return when {
            path.endsWith(".gz", true) ->
                RootShell.run("tail -c 4 $f | od -An -tu4").second.trim().toLongOrNull()
            path.endsWith(".xz", true) -> null
            isSparse(path) -> {
                val n = RootShell.run("od -An -tu4 -j12 -N8 $f").second.trim().split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }
                if (n.size == 2) n[0] * n[1] else null
            }
            else -> RootShell.run("stat -c %s $f").second.trim().toLongOrNull()
        }
    }

    fun isInstalled(): Boolean {
        val s = status()
        return s.contains("installed", true) && !s.contains("not installed", true)
    }

    fun start(path: String, systemSize: Long, userdataSize: Long): String {
        RootShell.run("logcat -c")
        val cmd = "am start-activity -n com.android.dynsystem/com.android.dynsystem.VerificationActivity " +
            "-a android.os.image.action.START_INSTALL -d ${q("file://$path")} " +
            "--el KEY_SYSTEM_SIZE $systemSize --el KEY_USERDATA_SIZE $userdataSize"
        return RootShell.run(cmd).second
    }

    fun tail(onLine: (String) -> Unit): Process = RootShell.stream("logcat -v threadtime -s $TAGS", onLine)

    fun status() = RootShell.run("gsi_tool status").second
    fun discard() = RootShell.run("gsi_tool wipe").second
    fun enable(oneShot: Boolean) = RootShell.run(if (oneShot) "gsi_tool enable -s" else "gsi_tool enable").second

    /** Leftovers of the previous (DSU) boot, read after returning to main OS. */
    fun lastBootReport(): List<Pair<String, String>> {
        fun sh(c: String) = RootShell.run(c).second.ifBlank { "(empty)" }
        return listOf(
            "Boot reason" to sh("getprop sys.boot.reason; getprop sys.boot.reason.last; getprop persist.sys.boot.reason.history"),
            "DSU status" to sh("gsi_tool status"),
            "pstore files" to sh("ls /sys/fs/pstore 2>&1"),
            "Kernel last console (pstore)" to sh("cat /sys/fs/pstore/console-ramoops* 2>/dev/null | tail -n 120"),
            "Last logcat (filtered)" to sh("logcat -L -d -v threadtime 2>&1 | grep -iE 'dynsystem|gsid|dsu|FATAL|AndroidRuntime|avb|verity|fiemap|snapshot|init: .*(fail|crash|reboot)' | tail -n 120"),
            "dmesg (this boot, filtered)" to sh("dmesg 2>&1 | grep -iE 'dsu|gsi|dm-verity|avb|panic|oops|watchdog' | tail -n 60"),
            "Recent crash/tombstone entries" to sh("ls -t /data/system/dropbox 2>/dev/null | head -n 10"),
            "DSU dirs" to sh("ls -la /data/gsi /metadata/gsi 2>&1 | head -n 30")
        )
    }
}
