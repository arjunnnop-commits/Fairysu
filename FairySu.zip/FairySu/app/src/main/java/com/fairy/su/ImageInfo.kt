package com.fairy.su

class Capture(val systemSize: Long?, val images: List<Pair<String, Long>>, val estimated: Boolean = false)

/** Auto-captures image sizes so the user never has to type the system size. */
object ImageInfo {
    fun capture(path: String): Capture {
        if (!path.endsWith(".zip", true)) return Capture(DsuRunner.autoSize(path), emptyList())
        val out = RootShell.run("unzip -l ${DsuRunner.q(path)}").second
        val re = Regex("""^\s*(\d+)\s+\S+\s+\S+\s+(\S.*)$""")
        val imgs = out.lines().mapNotNull { re.find(it) }
            .map { it.groupValues[2].trim() to (it.groupValues[1].toLongOrNull() ?: 0L) }
            .filter { it.first.endsWith(".img", true) }
        val sys = imgs.firstOrNull { it.first.substringAfterLast('/').equals("system.img", true) }?.second
        if (sys != null) return Capture(sys, imgs)
        val zipSize = RootShell.run("stat -c %s ${DsuRunner.q(path)}").second.trim().toLongOrNull()
        return Capture(zipSize, imgs, true)
    }
}
