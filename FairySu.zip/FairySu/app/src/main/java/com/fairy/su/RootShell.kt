package com.fairy.su

import java.io.BufferedReader
import java.io.InputStreamReader

object RootShell {
    /** Single root command, returns merged stdout+stderr. */
    fun run(cmd: String): Pair<Int, String> = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor() to out.trim()
    } catch (e: Exception) { -1 to "su failed: ${e.message}" }

    fun hasRoot() = run("id").second.contains("uid=0")

    /** Long-running command, every line goes to onLine. Returns the process so caller can destroy it. */
    fun stream(cmd: String, onLine: (String) -> Unit): Process {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        Thread {
            try { BufferedReader(InputStreamReader(p.inputStream)).forEachLine(onLine) } catch (_: Exception) {}
        }.start()
        return p
    }
}
